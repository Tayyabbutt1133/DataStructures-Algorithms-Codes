#include <iostream>
using namespace std;
# define n 100
struct Node {
	int data;
	Node* left;
	Node* right;
};